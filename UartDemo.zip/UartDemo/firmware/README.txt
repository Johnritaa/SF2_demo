Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v11.5 SP2 (Version 11.5.2.6)

Date    :    Sun May 31 16:18:22 2015
Project :    D:\Microsemiprj\UartDemo
