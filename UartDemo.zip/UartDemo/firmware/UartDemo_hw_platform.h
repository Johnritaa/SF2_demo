#ifndef UartDemo_HW_PLATFORM_H_
#define UartDemo_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Sun May 31 16:18:22 2015
*
*Memory map specification for peripherals in UartDemo
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Master(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/


#endif /* UartDemo_HW_PLATFORM_H_*/
